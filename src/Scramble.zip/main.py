from machine import Pin, SoftI2C
import ssd1306
import time

i2c = SoftI2C(scl=Pin(1), sda=Pin(0))

short_button = Pin(26, Pin.IN, Pin.PULL_DOWN)
long_button = Pin(21, Pin.IN, Pin.PULL_DOWN)
enter = Pin(28, Pin.IN, Pin.PULL_DOWN)

oled = ssd1306.SSD1306_I2C(128, 64, i2c)

morse = {
    "01":"A","1000":"B","1010":"C","100":"D","0":"E",
    "0010":"F","110":"G","0000":"H","00":"I","0111":"J",
    "101":"K","0100":"L","11":"M","10":"N","111":"O",
    "0110":"P","1101":"Q","010":"R","000":"S","1":"T",
    "001":"U","0001":"V","011":"W","1001":"X","1011":"Y","1100":"Z"
}

def scrambler(s):
    s= chr((ord(s) - 65 + 2) % 26 + 65)
    return s

def accept():
    s = ""
    while enter.value() == 0:
        if short_button.value() == 1:
            s += "0"
            time.sleep(0.2)
        elif long_button.value() == 1:
            s += "1"
            time.sleep(0.2)

    return morse.get(s, "?")

text = ""

while True:
    if enter.value() == 0:
        char = scrambler(accept())
        text = text + char
        time.sleep(0.5)

    oled.fill(0)
    oled.text(text, 0, 0)
    oled.show()